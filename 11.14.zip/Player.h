#pragma once
#include <iostream>
#include <vector>
#include "Map.h"
#include "Cards.h"
#include "Orders.h"

class Player
{
public:
	string name;
	vector<Territory*> territories;
    int armyPool;
	Hand* cards;
	OrdersList* orders;

	// constructors and destructors
	Player();
	Player(string pname);
	Player(const Player& p);
	~Player(); 

	// printers and accessors
	void printTerrOwn();		// print all the territories player owns
	void printOrder();			// print all the orders player has
	int getTerrNumber();

	// check if player has a specific territory by ID
	bool hasTerritory(int territoryID);

	vector<Territory*> toDefend();
	vector<Territory*> toAttack(Map* map);
	// creates an order and put on player's ordersList
	// will return true if an order is successfully created, return false if no more orders are being issued
	bool issueOrder(Map* map, Deck* deck);

	Player& operator =(const Player& p);
	friend ostream& operator <<(ostream &strm, Player &player);
};